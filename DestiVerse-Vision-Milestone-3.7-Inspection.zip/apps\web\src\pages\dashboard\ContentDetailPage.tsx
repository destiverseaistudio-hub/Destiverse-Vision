﻿import { Link, useParams } from "react-router-dom"
import {
  ArrowLeft,
  ChevronRight,
  Info,
  Play,
  Plus,
} from "lucide-react"

import { ContentCard } from "@/components/content/ContentCard"
import {
  allContent,
  getContentById,
  type ContentItem,
} from "@/data/content"

function getRelatedContent(item: ContentItem) {
  const sameCategory = allContent.filter(
    (candidate) =>
      candidate.id !== item.id && candidate.category === item.category,
  )

  const fallback = allContent.filter(
    (candidate) =>
      candidate.id !== item.id && candidate.category !== item.category,
  )

  return [...sameCategory, ...fallback].slice(0, 5)
}

export default function ContentDetailPage() {
  const { contentId } = useParams<{ contentId: string }>()
  const content = contentId ? getContentById(contentId) : undefined

  if (!content) {
    return (
      <main className="min-h-[calc(100vh-4rem)] px-4 py-8 sm:px-6 lg:px-8">
        <div className="mx-auto flex min-h-[60vh] max-w-[var(--dv-content-max-width)] items-center justify-center">
          <section className="w-full max-w-xl rounded-3xl border border-[var(--dv-border)] bg-[var(--dv-surface)] p-8 text-center shadow-[var(--dv-shadow-card)] sm:p-12">
            <div className="mx-auto mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-white/[0.06] text-white/60">
              <Info className="h-6 w-6" />
            </div>

            <p className="mb-2 text-xs font-semibold uppercase tracking-[0.18em] text-white/40">
              Content unavailable
            </p>

            <h1 className="text-2xl font-bold text-white sm:text-3xl">
              We couldn't find that title.
            </h1>

            <p className="mx-auto mt-3 max-w-md text-sm leading-6 text-white/50">
              The content may have moved or is not available in the current
              catalog.
            </p>

            <Link
              to="/dashboard/categories"
              className="mt-7 inline-flex items-center gap-2 rounded-xl bg-white px-5 py-3 text-sm font-semibold text-black transition hover:bg-white/90"
            >
              Browse content
              <ChevronRight className="h-4 w-4" />
            </Link>
          </section>
        </div>
      </main>
    )
  }

  const relatedContent = getRelatedContent(content)
  const isComingSoon = content.badge === "Coming Soon"

  return (
    <main className="pb-16">
      <section className="relative overflow-hidden border-b border-white/[0.06]">
        <div
          className={`absolute inset-0 ${content.artworkClass} opacity-40`}
          aria-hidden="true"
        />
        <div
          className="absolute inset-0 bg-gradient-to-r from-[#070707] via-[#070707]/90 to-[#070707]/55"
          aria-hidden="true"
        />
        <div
          className="absolute inset-0 bg-gradient-to-t from-[#070707] via-[#070707]/35 to-transparent"
          aria-hidden="true"
        />

        <div className="relative mx-auto max-w-[var(--dv-content-max-width)] px-4 py-6 sm:px-6 sm:py-8 lg:px-8 lg:py-10">
          <Link
            to="/dashboard/categories"
            className="mb-8 inline-flex items-center gap-2 rounded-full border border-white/10 bg-black/30 px-3.5 py-2 text-xs font-medium text-white/70 backdrop-blur-md transition hover:border-white/20 hover:text-white"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            Back to browse
          </Link>

          <div className="grid gap-8 lg:grid-cols-[minmax(0,1fr)_300px] lg:items-end xl:grid-cols-[minmax(0,1fr)_340px]">
            <div className="max-w-3xl">
              {content.badge ? (
                <span className="mb-4 inline-flex rounded-full border border-white/10 bg-white/[0.07] px-3 py-1.5 text-[10px] font-semibold uppercase tracking-[0.16em] text-white/70 backdrop-blur-md">
                  {content.badge}
                </span>
              ) : null}

              <h1 className="text-3xl font-black leading-[1.05] tracking-[-0.03em] text-white sm:text-4xl md:text-5xl lg:text-6xl">
                {content.title}
              </h1>

              <div className="mt-5 flex flex-wrap items-center gap-x-3 gap-y-2 text-xs font-medium text-white/55 sm:text-sm">
                <span>{content.type}</span>
                <span className="text-white/20">•</span>
                <span>{content.category}</span>
                <span className="text-white/20">•</span>
                <span>{content.meta}</span>
              </div>

              <p className="mt-6 max-w-2xl text-sm leading-7 text-white/65 sm:text-base sm:leading-8">
                {content.description}
              </p>

              <div className="mt-7 flex flex-wrap gap-3">
                <button
                  type="button"
                  disabled
                  className="inline-flex cursor-not-allowed items-center gap-2 rounded-xl bg-white px-5 py-3 text-sm font-semibold text-black opacity-60"
                  title="Playback will be available in the streaming playback milestone."
                >
                  <Play className="h-4 w-4 fill-current" />
                  {isComingSoon ? "Coming Soon" : "Watch"}
                </button>

                <button
                  type="button"
                  disabled
                  className="inline-flex cursor-not-allowed items-center gap-2 rounded-xl border border-white/10 bg-white/[0.06] px-5 py-3 text-sm font-semibold text-white/60 backdrop-blur-md"
                  title="Watchlist persistence will be enabled in a later platform milestone."
                >
                  <Plus className="h-4 w-4" />
                  Add to Watchlist
                </button>
              </div>
            </div>

            <div className="mx-auto w-full max-w-[280px] lg:max-w-none">
              <div
                className={`relative aspect-[2/3] overflow-hidden rounded-3xl border border-white/10 shadow-2xl ${content.artworkClass}`}
              >
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-black/20" />

                <div className="absolute inset-x-0 bottom-0 p-5">
                  <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-white/50">
                    {content.category}
                  </p>
                  <p className="mt-1 text-sm font-semibold text-white">
                    {content.type}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-[var(--dv-content-max-width)] px-4 pt-10 sm:px-6 lg:px-8 lg:pt-14">
        <div className="mb-5 flex items-end justify-between gap-4">
          <div>
            <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-white/35">
              Discover more
            </p>
            <h2 className="mt-1 text-xl font-bold tracking-tight text-white sm:text-2xl">
              More like this
            </h2>
          </div>

          <Link
            to="/dashboard/categories"
            className="hidden items-center gap-1 text-xs font-medium text-white/45 transition hover:text-white sm:inline-flex"
          >
            Browse all
            <ChevronRight className="h-4 w-4" />
          </Link>
        </div>

        {relatedContent.length > 0 ? (
          <div className="flex gap-4 overflow-x-auto pb-4 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden sm:gap-5">
            {relatedContent.map((item) => (
              <ContentCard key={item.id} item={item} />
            ))}
          </div>
        ) : (
          <div className="rounded-2xl border border-[var(--dv-border)] bg-[var(--dv-surface)] p-8 text-center text-sm text-white/45">
            More titles will appear here as the catalog grows.
          </div>
        )}
      </section>
    </main>
  )
}
