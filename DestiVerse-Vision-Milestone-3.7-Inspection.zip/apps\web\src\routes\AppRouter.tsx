﻿import { Navigate, Route, Routes } from "react-router-dom"

import DashboardPage from "@/pages/DashboardPage"
import LoginPage from "@/pages/LoginPage"
import ForgotPasswordPage from "@/pages/ForgotPasswordPage"
import ResetPasswordPage from "@/pages/ResetPasswordPage"
import SignUpPage from "@/pages/SignUpPage"
import ContentDetailPage from "@/pages/dashboard/ContentDetailPage"
import DashboardHome from "@/pages/dashboard/DashboardHome"
import CategoriesPage from "@/pages/dashboard/CategoriesPage"
import SearchPage from "@/pages/dashboard/SearchPage"
import WatchlistPage from "@/pages/dashboard/WatchlistPage"
import LibraryPage from "@/pages/dashboard/LibraryPage"
import ProfilePage from "@/pages/dashboard/ProfilePage"
import SettingsPage from "@/pages/dashboard/SettingsPage"
import ProtectedRoute from "@/routes/ProtectedRoute"

export default function AppRouter() {
  return (
    <Routes>
      <Route path="/" element={<LoginPage />} />
      <Route path="/forgot-password" element={<ForgotPasswordPage />} />
      <Route path="/reset-password" element={<ResetPasswordPage />} />
      <Route path="/signup" element={<SignUpPage />} />

      <Route
        path="/dashboard"
        element={
          <ProtectedRoute>
            <DashboardPage />
          </ProtectedRoute>
        }
      >
        <Route index element={<DashboardHome />} />
        <Route path="categories" element={<CategoriesPage />} />
        <Route path="search" element={<SearchPage />} />
        <Route path="watchlist" element={<WatchlistPage />} />
        <Route path="library" element={<LibraryPage />} />
        <Route path="profile" element={<ProfilePage />} />
        <Route path="settings" element={<SettingsPage />} />
        <Route path="content/:contentId" element={<ContentDetailPage />} />
      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}
